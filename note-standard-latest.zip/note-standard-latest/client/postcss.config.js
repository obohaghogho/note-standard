export default {
  plugins: {
    "autoprefixer": {},
  },
};
