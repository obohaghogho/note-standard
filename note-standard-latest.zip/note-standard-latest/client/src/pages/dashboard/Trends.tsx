import { useEffect, useState } from 'react';
import { Card } from '../../components/common/Card';
import { Loader2, TrendingUp, Users, FileText, Lock, Radio } from 'lucide-react';
import { API_URL } from '../../lib/api';
import { useSocket } from '../../context/SocketContext';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    BarElement,
    Title,
    Tooltip,
    Legend
} from 'chart.js';
import { Line, Bar } from 'react-chartjs-2';

ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    BarElement,
    Title,
    Tooltip,
    Legend
);

interface DailyStats {
    date: string;
    total_active_users: number;
    total_notes_created: number;
    top_tags: Record<string, number>;
}

export const Trends = () => {
    const [stats, setStats] = useState<DailyStats[]>([]);
    const [loading, setLoading] = useState(true);
    const { socket, connected } = useSocket();

    useEffect(() => {
        fetchStats();
    }, []);

    useEffect(() => {
        if (!socket) return;

        socket.on('stats_updated', (realtimeStats: DailyStats) => {
            console.log('[Trends] Real-time stats received:', realtimeStats);
            setStats(prev => {
                const today = realtimeStats.date;
                const existingToday = prev.find(s => s.date === today);
                if (existingToday) {
                    return prev.map(s => s.date === today ? realtimeStats : s);
                } else {
                    return [...prev, realtimeStats].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
                }
            });
        });

        return () => {
            socket.off('stats_updated');
        };
    }, [socket]);

    const fetchStats = async () => {
        try {
            const response = await fetch(`${API_URL}/api/analytics`);
            if (!response.ok) {
                console.error('Analytics API returned', response.status);
                return;
            }
            const data = await response.json();
            // Sort by date ascending for charts
            if (Array.isArray(data)) {
                setStats(data.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()));
            }
        } catch (error) {
            console.error('Error fetching trends:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return <div className="flex justify-center py-20"><Loader2 className="animate-spin text-primary" size={32} /></div>;
    }

    if (stats.length === 0) {
        return (
            <div className="space-y-6 max-w-6xl mx-auto">
                <div>
                    <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-3">
                        <TrendingUp className="text-primary" />
                        Community Trends
                    </h1>
                    <p className="text-gray-400 mt-1">Anonymous insights from the Note Standard community.</p>
                </div>
                <Card variant="glass" className="p-12 text-center">
                    <TrendingUp size={48} className="text-gray-600 mx-auto mb-4" />
                    <h3 className="text-lg font-bold text-gray-300 mb-2">No Trend Data Yet</h3>
                    <p className="text-gray-500 text-sm max-w-md mx-auto">
                        Community trends will appear here as users contribute and opt-in to Anonymous Analytics via Settings &gt; Privacy.
                    </p>
                </Card>
            </div>
        );
    }

    // Prepare Chart Data
    const labels = stats?.map(s => new Date(s.date).toLocaleDateString());

    const noteData = {
        labels,
        datasets: [
            {
                label: 'Global Notes Created (Anonymized)',
                data: stats?.map(s => s.total_notes_created),
                borderColor: 'rgb(59, 130, 246)',
                backgroundColor: 'rgba(59, 130, 246, 0.5)',
                tension: 0.4
            }
        ]
    };

    const activeUserData = {
        labels,
        datasets: [
            {
                label: 'Active Contributor Count',
                data: stats?.map(s => s.total_active_users),
                borderColor: 'rgb(168, 85, 247)',
                backgroundColor: 'rgba(168, 85, 247, 0.5)',
                tension: 0.4
            }
        ]
    };

    // Aggregate tags from all days
    const allTags: Record<string, number> = {};
    stats.forEach(day => {
        if (day.top_tags) {
            Object.entries(day.top_tags).forEach(([tag, count]) => {
                allTags[tag] = (allTags[tag] || 0) + count;
            });
        }
    });

    const sortedTags = Object.entries(allTags)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 10);

    const tagData = {
        labels: sortedTags?.map(([tag]) => tag),
        datasets: [
            {
                label: 'Trending Topics',
                data: sortedTags?.map(([, count]) => count),
                backgroundColor: [
                    'rgba(255, 99, 132, 0.7)',
                    'rgba(54, 162, 235, 0.7)',
                    'rgba(255, 206, 86, 0.7)',
                    'rgba(75, 192, 192, 0.7)',
                    'rgba(153, 102, 255, 0.7)',
                    'rgba(255, 159, 64, 0.7)',
                ],
            }
        ]
    };

    return (
        <div className="space-y-6 max-w-6xl mx-auto">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-3">
                        <TrendingUp className="text-primary" />
                        Community Trends
                    </h1>
                    <p className="text-gray-400 mt-1">
                        Anonymous insights from the Note Standard community.
                    </p>
                </div>
                <div className="flex items-center gap-2 sm:gap-4 flex-wrap">
                    {connected && (
                        <div className="flex items-center gap-1.5 text-[10px] text-red-500 font-bold bg-red-500/10 px-2 py-0.5 rounded-md animate-pulse border border-red-500/20">
                            <Radio size={12} />
                            LIVE
                        </div>
                    )}
                    <div className="flex items-center gap-2 text-xs text-green-400 bg-green-900/20 px-3 py-1.5 rounded-full border border-green-900/50">
                        <Lock size={12} />
                        Verified Privacy-Safe Data
                    </div>
                </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
                <Card variant="glass" className="p-6">
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                        <FileText size={18} className="text-blue-400" />
                        Productivity Pulse
                    </h3>
                    <div className="h-64">
                        <Line
                            data={noteData}
                            options={{
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: {
                                    legend: { position: 'bottom', labels: { color: '#9ca3af' } }
                                },
                                scales: {
                                    y: {
                                        beginAtZero: true,
                                        grid: { color: 'rgba(255,255,255,0.05)' },
                                        ticks: { color: '#9ca3af' }
                                    },
                                    x: {
                                        grid: { color: 'rgba(255,255,255,0.05)' },
                                        ticks: { color: '#9ca3af' }
                                    }
                                }
                            }}
                        />
                    </div>
                </Card>

                <Card variant="glass" className="p-6">
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                        <Users size={18} className="text-purple-400" />
                        Active Contributors
                    </h3>
                    <div className="h-64">
                        <Line
                            data={activeUserData}
                            options={{
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: {
                                    legend: { position: 'bottom', labels: { color: '#9ca3af' } }
                                },
                                scales: {
                                    y: {
                                        beginAtZero: true,
                                        grid: { color: 'rgba(255,255,255,0.05)' },
                                        ticks: { color: '#9ca3af' }
                                    },
                                    x: {
                                        grid: { color: 'rgba(255,255,255,0.05)' },
                                        ticks: { color: '#9ca3af' }
                                    }
                                }
                            }}
                        />
                    </div>
                </Card>
            </div>

            <Card variant="glass" className="p-6">
                <h3 className="text-lg font-semibold mb-4">Top Trending Topics</h3>
                <div className="h-80">
                    <Bar
                        data={tagData}
                        options={{
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: { display: false }
                            },
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    grid: { color: 'rgba(255,255,255,0.05)' },
                                    ticks: { color: '#9ca3af' }
                                },
                                x: {
                                    grid: { display: false },
                                    ticks: { color: '#9ca3af' }
                                }
                            }
                        }}
                    />
                </div>
            </Card>

            <div className="bg-white/5 border border-white/10 rounded-lg p-4 text-center">
                <p className="text-sm text-gray-400">
                    Want to contribute to these stats? Go to <a href="/dashboard/settings?tab=privacy" className="text-primary hover:underline">Settings &gt; Privacy</a> and opt-in to Anonymous Analytics.
                </p>
            </div>
        </div>
    );
};

export default Trends;
